﻿Dupe Goblin v1.0.13

New in this build:
- Added an "Ignore hidden files and folders" checkbox under Scan options.
- The option is OFF by default, preserving the existing scan behavior.
- When enabled, files/folders marked Hidden by Windows are skipped.
- Hidden folders are not traversed, so their contents are skipped too.
- The generated report records whether hidden items were ignored.
- Scanner remains read-only. It does not delete, move, rename, or modify scanned files.

DUPE GOBLIN
===========

A read-only Windows duplicate file scanner.

QUICK START
-----------
1. Keep all files in this folder together.
2. Double-click: Launch Dupe Goblin.bat

OPTIONAL DESKTOP ICON
---------------------
Double-click: Create Dupe Goblin Desktop Shortcut.bat

That creates a Desktop shortcut using the custom Dupe Goblin icon.
After that, launch the app from the Desktop shortcut.

WHAT IT DOES
------------
- Lets you select any currently available drives with checkboxes.
- Lets you add one or more specific folders.
- Optional checkbox to ignore hidden files and folders.
- Scans all folders and subfolders.
- Shows a progress row for every selected drive/folder.
- Shows total progress, percentages, and ETA when it can be calculated.
- Uses file size first, then SHA-256 to verify exact duplicates.
- Shows results in the GUI.
- Writes a simple text report inside the program folder:
  Logs\Dupe Goblin - Duplicate Report.txt

  The Logs folder is created automatically.
- Lets you open a selected result in Windows Explorer.
- Supports cancellation.
- Uses a scrollable interface so controls stay reachable when the window is small.

WHAT IT DOES NOT DO
-------------------
Dupe Goblin has no delete feature.
It does not move, rename, overwrite, edit, or otherwise modify scanned files.

NOTES
-----
- Junctions and symbolic-link folders are skipped to prevent recursion loops.
- Inaccessible folders/files are skipped and counted in the report.
- If you select a whole drive and also add a folder inside that same drive,
  the nested folder is automatically ignored as a separate scan source so the
  same files are not scanned twice.


V1.0.1 UI fixes:
- Drive selector is now a vertical list.
- Corrected the Add folder(s) button label.
- Removed fixed-width layout constraints so content follows the window width.
- Results area grows with larger windows and remains scrollable in smaller windows.
- Updated transparent Dupe Goblin branding/icon.


v1.0.6: Reworked duplicate candidate grouping to happen incrementally during indexing. This prevents the UI from appearing frozen at 45% on large scans and removes the blocking Group-Object passes.


RESULTS
- Select a duplicate and click "Open selected file location" to open Explorer with that exact file highlighted.
- You can also double-click a duplicate row or right-click it and choose "Open file location".


v1.0.13: Refined the header branding. The app now uses a mascot-only image on the left and the stylized Dupe Goblin logo wordmark as the main title.
