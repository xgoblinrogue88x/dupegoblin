$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Dupe Goblin.lnk'
$powerShellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$appScript = Join-Path $PSScriptRoot 'Dupe Goblin.ps1'
$iconPath = Join-Path $PSScriptRoot 'Dupe Goblin.ico'

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $powerShellPath
$shortcut.Arguments = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}"' -f $appScript)
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.IconLocation = ('{0},0' -f $iconPath)
$shortcut.Description = 'Dupe Goblin - read-only duplicate file scanner'
$shortcut.Save()

[System.Windows.Forms.MessageBox]::Show(
    'Dupe Goblin shortcut created on your Desktop.',
    'Dupe Goblin',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null
