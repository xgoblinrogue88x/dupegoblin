@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; & '%~dp0Create Dupe Goblin Desktop Shortcut.ps1'"
exit /b
